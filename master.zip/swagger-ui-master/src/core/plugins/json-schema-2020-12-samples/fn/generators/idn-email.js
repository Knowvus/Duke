/**
 * @prettier
 */
const idnEmailGenerator = () => "실례@example.com"

export default idnEmailGenerator
